﻿

using System;
using System.Collections.Generic;

namespace KladrAPIClientExample
{
    using KladrApiClient;
    using System.Windows;
    using System.IO;
    using System.Text;
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private KladrClient kladrClient;
        public MainWindow()
        {
            InitializeComponent();
            kladrClient = new KladrClient("596b688a0a69dead448b457a", "");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           
            List<string[]> list = new List<string[]>();
            try
            {
                FileStream fs = new FileStream(@"C:\Dir\kladr.csv", FileMode.Open);
            StreamReader sr = new StreamReader(fs, Encoding.GetEncoding("windows-1251"));
            while (sr.EndOfStream != true)
            {
                string Line = sr.ReadLine();
                string[] s = Line.Split(',');
                list.Add(s);
                
            }
            sr.Close();
            }
            catch (Exception err)
                {
                    MessageBox.Show("{0} Exception caught.", err.Message);
                }

            string[] alphabet = { "а", "б", "в", "г", "д", "е", "ж", "з", "и", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "э", "ю", "я" };
            
            for (int z = 0; z < list.Count; z++ )
            {
                for (int i = 0; i < alphabet.Length; i++)
                {
                    string l = list[z][3];
                    kladrClient.FindAddress(new Dictionary<string, string>
                                        {
                                            {"cityId", l},
                                            {"query", alphabet[i]},
                                            {"contentType", "street"},
                                            {"withParent", "1"}
                                            
                                        }, fetchedAddress);
                }
            }
            for (int i = 0; i < alphabet.Length; i++)
            {
                kladrClient.FindAddress(new Dictionary<string, string>
                                        {
                                            {"query", alphabet[i]},
                                            {"contentType", "city"},
                                            {"withParent", "1"}
                                            
                                        }, fetchedAddress);
            }
        }

        private void fetchedAddress(KladrResponse response)
        {
            if(response!=null)
            {
                if (response.result != null && response.InfoMessage.Equals("OK"))
                {
                    
                    List<string> spisok = new List<string>();
                    for (int i = 0; i < response.result.Length; i++)
                    {
                        string cityName = response.result[i].name;
                        spisok.Add(cityName);

                    }

                    if (response.result[0].id.Length < 14) //id города 13 цифр, а у улицы больше
                        System.IO.File.WriteAllLines(@"C:\Dir\city.txt", spisok);
                    else
                    {
                        string k = response.result[0].parents[1].name;
                        k = Translit(k);
                        System.IO.File.WriteAllLines(@"C:\Dir\" + k + ".txt", spisok);
                    }
                }
                    
            }
        }

        public static string Translit(string str)
        {
            string[] lat_up = { "A", "B", "V", "G", "D", "E", "Yo", "Zh", "Z", "I", "Y", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "F", "Kh", "Ts", "Ch", "Sh", "Shch", "\"", "Y", "'", "E", "Yu", "Ya" };
            string[] lat_low = { "a", "b", "v", "g", "d", "e", "yo", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f", "kh", "ts", "ch", "sh", "shch", "\"", "y", "'", "e", "yu", "ya" };
            string[] rus_up = { "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ", "Ъ", "Ы", "Ь", "Э", "Ю", "Я" };
            string[] rus_low = { "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я" };
            for (int i = 0; i <= 32; i++)
            {
                str = str.Replace(rus_up[i], lat_up[i]);
                str = str.Replace(rus_low[i], lat_low[i]);
            }
            return str;
        }
       
    }
}
